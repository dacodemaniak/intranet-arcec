<?php
/**
 * @name porteurMapper.class.php : Mapping de la table prefix_porteur
 * @author web-Projet.com (jean-luc.aubert@web-projet.com)
 * @package arcec\Mapper
 * @version 1.0
 **/
namespace arcec\Mapper;

class porteurMapper extends \wp\dbManager\dbMapper {
	/**
	 * Identifiant du dossier courant
	 * @var int
	**/
	private $dossierId;
	
	/**
	 * @property int $id Identifiant du porteur
	 * @property date $datenaissance Date de naissance
	 * @property string $nom Nom du paramètre
	 * @property int $type_table_param_id Identifiant du type de paramètre (voir typetableparamMapper)
	**/
	

	
	public function __construct($dossierId=null){
		$this->dossierId = $dossierId;
		
		$classParts = explode("\\",__CLASS__);
		$className = array_pop($classParts);
		
		$this->namespace = implode("\\",$classParts);
		
		$this->className = substr($className,0,strpos($className,"Mapper"));
		
		$this->columnPrefix = "porteur_";
		
		$this->alias = "por";
		
		
		$this->defineScheme();
		
		$this->dependencies[] = array();
		
		$this->namespace = __NAMESPACE__;
	}
	
	private function defineScheme(){
		$parentMapper = new \arcec\Mapper\dossierMapper();
		if(!is_null($this->dossierId))
			$parentMapper->setId($this->dossierId); // Dossier précédemment créé
		
		$this->scheme = array(
			"id" => array("type" => "int", "index" => "primary", "autoincrement" => true, "null" => false),
			"datenaissance" => array("type" => "date","null"=>false),
			"adrnum" => array("type" => "varchar","size"=>5,"null"=>true),
			"voi" =>  array("type" => "int","null"=>false),
			"adr1" => array("type" => "varchar","size" => 75, "null" => true),
			"adr2" => array("type" => "varchar","size" => 75, "null" => true),
			"codepostal" => array("type" => "varchar","size" => 10, "null" => false),
			"ville" => array("type" => "varchar","size" => 75, "null" => false),
			"telfixe" => array("type" => "varchar","size" => 20, "null" => false),
			"telportable" => array("type" => "varchar","size" => 20, "null" => false),
			"email" => array("type" => "varchar","size" => 75, "null" => true),
			"dpl" =>  array("type" => "int","null"=>false),
			"specdiplome" => array("type" => "varchar","size" => 75, "null" => true),
			"prs" =>  array("type" => "int","null"=>false),
			"emailpresc" => array("type" => "varchar","size" => 75, "null" => true),
			"nompresc" => array("type"=>"varchar","size"=>75, "null"=>true),
			"sis" =>  array("type" => "int","null"=>false),
			"precisionsis" => array("type" => "varchar","size" => 75, "null" => true),
			"dateinscpoleemploi" => array("type" => "date","null"=>false),
			"cnt" =>  array("type" => "int","null"=>false),
			"anciennetecnt" => array("type" => "varchar","size" => 75, "null" => true),
			"resumeprojet" => array("type" => "text","null"=>true),
			"dateaccueil" => array("type" => "date","null"=>false),
			"geneseprojet" => array("type" => "text","null"=>true),
			"demande" => array("type" => "text","null"=>true),
			"datedepotdossier" => array("type" => "date","null"=>false),
			"dateacceptationdossier" => array("type" => "date","null"=>false),
			"nat" =>  array("type" => "int","null"=>false),
			"sif" =>  array("type" => "int","null"=>false),
			"rim" =>  array("type" => "int","null"=>false),
			"rin" =>  array("type" => "int","null"=>true),
			"cnscoord" =>  array("type" => "int","null"=>true),
			"handicap" => array("type"=>"tinyint","default"=>0),
			"sexe" => array("type" => "char","size"=>1,"null"=>false,"default"=>"M"),
			"eligibleaccre" => array("type"=>"tinyint","default"=>0),
			"eligiblenacre" => array("type"=>"tinyint","default"=>0),
			"eligiblefongecif" => array("type"=>"tinyint","default"=>0),
			"dossier_id" => array("type" => "int","foreign_key" => true, "parent_table" => "dossier", "null" => false,"mapper" => $parentMapper)
		);
	}

	public function count(){
		$requete = "SELECT COUNT(*) AS nbrows
			FROM " . $this->getTableName();
		
		// Ajoute les contraintes à partir des données de recherche
		if(!is_null($this->clause)){
			$requete .= " WHERE ";
			for($i=0; $i<sizeof($this->clause);$i++){
				$requete .= $this->clause[$i]["column"] . " " . $this->clause[$i]["operateur"] . " :" . $this->clause[$i]["column"] . " AND ";
				$params[$this->clause[$i]["column"]] = $this->clause[$i]["value"];
			}
			// Supprime le dernier " AND "
			$requete = substr($requete,0,strlen($requete) - strlen(" AND "));
		}		
		$dbInstance = \wp\dbManager\dbConnect::dbInstance();
		$query = $dbInstance->getConnexion()->prepare($requete);
		$query->execute($params);
		$query->setFetchMode(\PDO::FETCH_OBJ);
		$row = $query->fetch();
	
		return (integer) $row->nbrows;
	}
	
	/**
	 * 
	 * @param string $attrName : Nom de l'attribut / colonne
	 * @param mixed $attrValue : Valeur de l'attribut / colonne
	 */
	public function __set($attrName,$attrValue){
		if(!property_exists($this,$attrName) && $this->in($attrName)){
			$this->{$attrName} = $attrValue;
			return true;
		}
		return false;
	}
	
	public function __get($attrName){
		if(!property_exists($this,$attrName)){
			return $this->{$attrName};
		}
		return;
	}
	
	public function getCheckBox(){
		return $this->setCheckBox();
		
	}
	private function setCheckBox(){
		$checkbox = new \wp\formManager\Fields\checkbox();
		$checkbox->setId("id_" . $this->id)
			->setName("id_" . $this->id)
			->setValue($this->id)
			->isDisabled(!$this->checkIntegrity($this->id))
		;
		return $checkbox;
	}
}
?>